Source code for https://www.youtube.com/watch?v=jc9_Bqzy2YQ&feature=youtu.be 
