/** @format */

import "./App.css";
import Home from "./Components/page/Home";
function App() {
	return (
		<>
			<div className=''>
				<Home />
			</div>
		</>
	);
}

export default App;
