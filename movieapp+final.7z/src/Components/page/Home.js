/** @format */

// export default Home;
import React, { useEffect, useState } from "react";
// import ARFMovies from "./Components/ARFMovies";
import MovieList from "../MovieList";
import SearchBox from "../SearchBox";
// import FavouriteMoviesArea from "../Containers/FavouriteMoviesArea";
import FavouriteMovies from "../FavouriteMovies";
import FooterArea from "../Containers/FooterArea";
// import AddFev from "./Components/AddFev";
import Heading from "../Heading";
import ScrollToTop from "../Funyionality/ScrollToTop";
import DarkModeToggle from "../Funyionality/DarkMode";
// import FavouriteMoviesArea from "../Containers/FavouriteMoviesArea";

function Home() {
	const [movies, setMovies] = useState([
		{
			Title: "Star Wars: Empire at War",
			Year: "2006",
			imdbID: "tt0804909",
			Type: "game",
			Poster:
				"https://m.media-amazon.com/images/M/MV5BOGRiMDllMDUtOWFkZS00MGIyLWFkOTQtZjY2ZGUyNzY5YWRiXkEyXkFqcGdeQXVyMzM4MjM0Nzg@._V1_SX300.jpg",
		},
		{
			Title: "Star Wars: Empire at War",
			Year: "2006",
			imdbID: "tt0804909",
			Type: "game",
			Poster:
				"https://m.media-amazon.com/images/M/MV5BOGRiMDllMDUtOWFkZS00MGIyLWFkOTQtZjY2ZGUyNzY5YWRiXkEyXkFqcGdeQXVyMzM4MjM0Nzg@._V1_SX300.jpg",
		},
		{
			Title: "Star Wars: Empire at War",
			Year: "2006",
			imdbID: "tt0804909",
			Type: "game",
			Poster:
				"https://m.media-amazon.com/images/M/MV5BOGRiMDllMDUtOWFkZS00MGIyLWFkOTQtZjY2ZGUyNzY5YWRiXkEyXkFqcGdeQXVyMzM4MjM0Nzg@._V1_SX300.jpg",
		},
		{
			Title: "Star Wars: Empire at War",
			Year: "2006",
			imdbID: "tt0804909",
			Type: "game",
			Poster:
				"https://m.media-amazon.com/images/M/MV5BOGRiMDllMDUtOWFkZS00MGIyLWFkOTQtZjY2ZGUyNzY5YWRiXkEyXkFqcGdeQXVyMzM4MjM0Nzg@._V1_SX300.jpg",
		},
		{
			Title: "Star Wars: Empire at War",
			Year: "2006",
			imdbID: "tt0804909",
			Type: "game",
			Poster:
				"https://m.media-amazon.com/images/M/MV5BOGRiMDllMDUtOWFkZS00MGIyLWFkOTQtZjY2ZGUyNzY5YWRiXkEyXkFqcGdeQXVyMzM4MjM0Nzg@._V1_SX300.jpg",
		},
	]);
	const [favourites, setFavourites] = useState([]);
	const [searchValue, setSearchValue] = useState("");

	const getMovieRequest = async (searchValue) => {
		const url = `https://www.omdbapi.com/?s=${searchValue}&apikey=84c2ff0e`;
		const response = await fetch(url);
		const responseJason = await response.json();

		if (responseJason.Search) {
			setMovies(responseJason.Search);
		}
	};

	useEffect(() => {
		getMovieRequest(searchValue);
	}, [searchValue]);

	useEffect(() => {
		const movieFavourites = JSON.parse(localStorage.getItem("react-movie-app"));

		if (movieFavourites) {
			setFavourites(movieFavourites);
		}
	}, []);

	const saveToLocalStorage = (items) => {
		localStorage.setItem("react-movie-app", JSON.stringify(items));
	};

	const addFavouritesMovies = (movie) => {
		const newFavouritesList = [...favourites, movie];
		setFavourites(newFavouritesList);
		saveToLocalStorage(newFavouritesList);
	};

	const removeFavouritesMovies = (movie) => {
		const newFavouritesList = favourites.filter(
			(favourite) => favourite.imdbID !== movie.imdbID
		);
		setFavourites(newFavouritesList);
	};

	return (
		<div className='w-11/12 mx-auto mt-8'>
			<div className='mb-4 sticky top-0 z-30'>
				<div className=' rounded-xl p-4 flex flex-col sm:flex-row justify-between items-center pb-4  bg-blue-400 dark:bg-slate-400'>
					<Heading Head='MovieApp' />
					<DarkModeToggle />
					<SearchBox
						searchValue={searchValue}
						setSearchValue={setSearchValue}
					/>
				</div>
			</div>

			<MovieList chinema={movies} handleFavouritesClick={addFavouritesMovies} />

			<FavouriteMovies
				chinema={favourites}
				handleFavouritesClick={removeFavouritesMovies}
			/>
			<ScrollToTop />
			<FooterArea />
		</div>
	);
}
export default Home;
