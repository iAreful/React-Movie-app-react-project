/** @format */

import React from "react";

import { GrReactjs } from "react-icons/gr";
import { AiFillApi } from "react-icons/ai";
import { SiTailwindcss } from "react-icons/si";
import { HiCode } from "react-icons/hi";
function Footer() {
	return (
		<section className=''>
			<div className='flex flex-col space-y-4 sm:space-y-0 sm:flex-row justify-between items-center '>
				<div className='flex flex-row gap-4'>
					<p className='dark:text-white text-blue-400 text-xl'>
						Made by Areful with
					</p>
					<GrReactjs className='block  text-3xl dark:text-white text-blue-600 pb-1' />
					<AiFillApi className='block  text-3xl dark:text-white  text-blue-600 pb-1' />
					<SiTailwindcss className='block  text-3xl dark:text-white  text-blue-600 pb-1' />
				</div>
				<div>
					<a href='/' className='flex flex-row'>
						<p className='dark:text-white text-blue-400 text-xl'>Code view</p>{" "}
						<HiCode className='block ml-2 text-3xl dark:text-white  text-blue-400  hover:text-blue-800 pb-1' />
					</a>
				</div>
			</div>
		</section>
	);
}

export default Footer;
