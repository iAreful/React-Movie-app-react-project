/** @format */

import React from "react";

function Heading(props) {
	return (
		<div>
			<h2 className='text-3xl font-bold py-2 text-white dark:text-slate-100'>
				{props.Head}
			</h2>
		</div>
	);
}

export default Heading;
