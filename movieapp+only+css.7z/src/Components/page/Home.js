/** @format */

import React from "react";
import Header from "../Containers/Header";
import MoviesAvialable from "../Containers/MoviesAvialable";
import FavouriteMoviesArea from "../Containers/FavouriteMoviesArea";
import FooterArea from "../Containers/FooterArea";

function Home() {
	return (
		<div className='w-11/12 mx-auto mt-8 overflow-x-hidden'>
			<Header />

			<MoviesAvialable />
			<FavouriteMoviesArea />
			<FooterArea />
		</div>
	);
}

export default Home;
