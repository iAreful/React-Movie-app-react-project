/** @format */

import React from "react";
import Footer from "../Footer";
function FooterArea() {
	return (
		<div>
			<div className=' mt-4 mb-96 bg-white dark:bg-slate-400 p-4 rounded-xl mx-auto flex flex-row justify-between pt-4  '>
				<Footer />
			</div>
		</div>
	);
}

export default FooterArea;
