/** @format */

import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
// import { FaHeartBroken } from "react-icons/bs";
import { FaHeartBroken } from "react-icons/fa";
// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import "./FavouriteMovies.css";

// import "./styles.css";

// import required modules
import { Autoplay, Navigation, Pagination, Mousewheel, Keyboard } from "swiper";
function FavouriteMovies() {
	return (
		<div className='flex flex-row gap-2'>
			<Swiper
				slidesPerView='2'
				spaceBetween={30}
				// loopedSlides={10000}
				loop={true}
				cssMode={true}
				navigation={true}
				pagination={true}
				mousewheel={true}
				keyboard={true}
				breakpoints={{
					// when window width is >= 640px
					640: {
						width: 640,
						slidesPerView: 2,
						spaceBetween: 20,
					},
					// when window width is >= 768px
					768: {
						width: 768,
						slidesPerView: 4,
						spaceBetween: 20,
					}, // when window width is >= 1024px
					1024: {
						width: 1024,
						slidesPerView: 5,
						spaceBetween: 20,
					},
				}}
				autoplay={{
					delay: 1900,
					disableOnInteraction: false,
				}}
				modules={[Autoplay, Navigation, Pagination, Mousewheel, Keyboard]}
				className='mySwiper'>
				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>

				<SwiperSlide>
					<div className='movie-poster relative w-48 h-64 bg-blue-400 rounded-xl'>
						<div className='add-fev absolute bottom-6 left-0 bg-slate-100 bg-opacity-20 w-48 rounded-xl py-2'>
							<p className='text-md text-center'>Add to this Favrourite </p>
							<FaHeartBroken className='block ml-[5rem] mt-2 text-2xl text-red-600 hover:text-red-500' />
						</div>
						{/* movie Info */}.
						<div className='add-fev absolute top-0 left-0 bg-slate-200 bg-opacity-20 rounded-xl w-48 py-4 '>
							<p className='text-lg text-center '>Movie Name </p>
							<p className='text-md  text-center'>2014 </p>
							<p className='text-md  text-center mt-4'>
								<a
									href='/'
									className='bg-slate-100 bg-opacity-50 border-1 border-white px-2 py-1 rounded-xl font-semibold'>
									detail
								</a>{" "}
							</p>
						</div>
					</div>
				</SwiperSlide>
			</Swiper>
		</div>
	);
}

export default FavouriteMovies;
